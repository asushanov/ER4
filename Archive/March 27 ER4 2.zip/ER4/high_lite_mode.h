#ifndef HIGH_LITE_MODE_H
#define HIGH_LITE_MODE_H

#import "import.h"

class High_lite_mode : QSyntaxHighlighter
{

    Q_OBJECT

    public:
        High_lite_mode(QTextDocument *parent = 0);
        void highlightBlock(const QString &text);

    private:
        struct HighlightingRule
        {
            QRegExp pattern;
            QTextCharFormat format;
        };
        QVector<HighlightingRule> highlightingRules;

        QRegExp commentStartExpression;
        QRegExp commentEndExpression;

        QTextCharFormat keywordFormat;
        QTextCharFormat classFormat;
        QTextCharFormat singleLineCommentFormat;
        QTextCharFormat multiLineCommentFormat;
        QTextCharFormat quotationFormat;
        QTextCharFormat functionFormat;

};


#endif // HIGH_LITE_MODE_H
