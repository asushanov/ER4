#ifndef TREEPROJECTVIEW_H
#define TREEPROJECTVIEW_H

#include <QTreeWidget>
#include <QDirModel>
#include "Project.h"
#include "mydirmodel.h"
#include "mytreeview.h"

class Project;
class Manager;

class TreeProjectView
{
public:
    MyDirModel *model;

    TreeProjectView();
    void updateFileList(const Project* Pr);         // Update project in view, based on its parameters
    void setManager(Manager* pM);
    MyTreeView* getTreeView();
    QStringList getExpandedList();
    void setExpandedList(const QStringList expands);
    QString getCurProjName();
    void updateColumnWidth();

    bool hide_file_name;    // File name in treeView
    bool hide_file_size;    // File size in treeView
    bool hide_file_kind;    // File kind in treeView
    bool hide_file_date;    // File data modified in treeView

public slots:


private:
    Manager* pManager;
    MyTreeView treeView;
    QString currect_project_name;

};

#endif // TREEPROJECTVIEW_H
