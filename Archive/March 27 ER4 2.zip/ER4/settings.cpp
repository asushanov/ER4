#include "settings.h"

Settings::Settings()
{
    save_expanded_history = true;
    save_only_last_proj_exp_history = true;
    expand_on_proj_change = true;
    init_done = false;
    show_hints = true;
}
