#include "mytabwidget.h"

myTabWidget::myTabWidget(QWidget *parent) :
    QTabWidget(parent)
{
}

void myTabWidget::setNewTabBar(QTabBar *tB)
{
    this->setTabBar(tB);
}
