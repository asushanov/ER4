#ifndef PROJECT_H
#define PROJECT_H

#include "import.h"

class Project
{
public:
    QString path;       // Project path
    QString name;       // Project name
    QStringList filter;     // Extensions filter
    QStringList persistent; // Expanded folders
};

#endif // PROJECT_H
