#ifndef MYTAB_H
#define MYTAB_H

#include "import.h"
#include <QWidget>

class MyTab : public QWidget
{
    Q_OBJECT
public:
    explicit MyTab(QWidget *parent = 0);

    QTextEdit* document;

signals:

public slots:

};

#endif // MYTAB_H
