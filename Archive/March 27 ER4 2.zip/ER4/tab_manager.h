#ifndef TAB_MANAGER_H
#define TAB_MANAGER_H

#include "import.h"
#include "tab_info.h"

class Manager;

class Tab_manager
{
public:
    Tab_manager();
    void setManager(Manager* pM);
    bool tabExist(QString path) const;
    void addTab(Tab_info tB);
    void switchToTab(QString path);
    int getIndexByName(QString path) const;
    void setActive(int index);
    Tab_info* getTabInfo(int pos);

private:
    Manager* pManager;
    QVector<Tab_info> tabs;
};

#endif // TAB_MANAGER_H
