#include "new_project_w.h"

bool name_correct = false;  // Flag project name is correct
bool path_correct = false;  // Flag path to project is correct

ProjectWindow::ProjectWindow(QWidget *parent) : QDialog(parent)
 {
    projLabel = new QLabel(tr("Project name:"));        // Label Info - project
    pathLabel = new QLabel(tr("Path:"));                // Label Info - path
    projEdit = new QLineEdit();                         // Create test edit for project name
    pathComboBox = createComboBox(tr("PATH"));          // Create combobox to choose path to project
    extensionLabel = new QLabel(tr("File extensions")); // List of extensions label
    extensionComboBox = createComboBox(tr("EXTENSIONS"));   // List of extensions
    browseButton = createButton(tr("&Browse"), SLOT(browse())); // Button to open file-browser
    addButton = createButton(tr("& Add "), SLOT(add()));        // Button to add projects to main window
    closeButton = createButton(tr("&Close"), SLOT(close()));    // Close new project window
    fileView = new QTreeView();             // View of all files, using extensons in current path
    model = new QDirModel;      // File System model

    // Organize visible components
    mainLayout = new QGridLayout;
    buttonsLayout = new QHBoxLayout;
    mainLayout->addWidget(projLabel, 0, 0);
    mainLayout->addWidget(projEdit, 0, 1, 1, 2);
    mainLayout->addWidget(pathLabel, 1, 0);
    mainLayout->addWidget(pathComboBox, 1, 1, 1, 2);
    mainLayout->addWidget(extensionLabel, 2, 0);
    mainLayout->addWidget(extensionComboBox, 2, 1);
    mainLayout->addWidget(browseButton, 2, 2);
    mainLayout->addWidget(fileView, 3, 0, 1, 3);
    buttonsLayout->addStretch();
    buttonsLayout->addWidget(closeButton, 0);
    buttonsLayout->addWidget(addButton, 1, Qt::AlignRight);
    mainLayout->addLayout(buttonsLayout, 4, 0, 1, 3);
    setLayout(mainLayout);

    // Change extensions -> Update list of files in view
    connect(this->extensionComboBox, SIGNAL(editTextChanged(QString)), this, SLOT(updateFileList()));
    // Change path -> Update list of files in view
    connect(this->pathComboBox, SIGNAL(editTextChanged(QString)), this, SLOT(updateFileList()));
    // Change project name -> Check that it does not exists
    connect(this->projEdit, SIGNAL(textChanged(QString)), this, SLOT(checkName()));

    setWindowTitle(tr("Add new project"));
    resize(600, 370);
 }

QComboBox *ProjectWindow::createComboBox(const QString &text)
{
    // Default values in comboboxes
    QComboBox *comboBox = new QComboBox;
    comboBox->setEditable(true);
    if (text == "EXTENSIONS") {
        for (int i = 0; i<extensions.size(); i++)
        comboBox->addItem(extensions[i]);
    } else if (text == "PATH") {

    };
    comboBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    return comboBox;
}

QPushButton *ProjectWindow::createButton(const QString &text, const char *member)
{
    QPushButton *button = new QPushButton(text);
    connect(button, SIGNAL(clicked()), this, member);
    return button;
}

void ProjectWindow::browse()
{
    QString directory = QFileDialog::getExistingDirectory(this, tr("Find Files"), "~/");
    if (!directory.isEmpty()) {
        if (pathComboBox->findText(directory) == -1)
            // Add new possible path to default list
            pathComboBox->addItem(directory);
        pathComboBox->setCurrentIndex(pathComboBox->findText(directory));
    }
}

static void updateComboBox(QComboBox *comboBox)
{
    // Add new correct not existed item to combobox
    if (comboBox->findText(comboBox->currentText()) == -1)
        comboBox->addItem(comboBox->currentText());
}

void ProjectWindow::add()
{
    // Udate view of all files using filters
    this->updateFileList();
    // Add new possible path and extensions for fast future using
    updateComboBox(extensionComboBox);
    updateComboBox(pathComboBox);
    // Add new valid project to main window
    pManager->AddNewProject(new_project);
    this->hide();
}

void ProjectWindow::close()
{
    pathComboBox->clearEditText();
    projEdit->clear();
    this->hide();
}

 void ProjectWindow::setManager(Manager *pM)
 {
     pManager = pM;
 }

 void ProjectWindow::updateFileList()
 {

    QString extensions_not_parsed = extensionComboBox->currentText();
    // Set default extension "*.*" if field is empty
    if (extensions_not_parsed.isEmpty())
         extensions_not_parsed = "*.*";
    // Get data from test edit and comboboxes
    QStringList extensions = extensions_not_parsed.split(" ");
    QString path = pathComboBox->currentText();
    // Set flasg that path correct
    path_correct = QDir().exists(path);
    currentDir = QDir(path);
    QStringList files;
    //List of all files using filters (not used for now)
    files = currentDir.entryList(QStringList(extensions), QDir::Files | QDir::NoSymLinks | QDir::AllDirs | QDir::NoDotAndDotDot);
    // Model filter "what to show"
    model->setFilter(QDir::AllDirs | QDir::Files | QDir::NoSymLinks | QDir::NoDotAndDotDot);
    model->setNameFilters(QStringList(extensions));
    fileView->setModel(model);
    fileView->setRootIndex(model->index(path));
    fileView->setColumnWidth(0, 400);

    // Update Project data
    new_project.filter = extensions;
    new_project.path = path;
    updateAddButtonState();
 }

 void ProjectWindow::reset()
 {
    this->projEdit->clear();
    this->pathComboBox->clearEditText();
    this->addButton->setEnabled(false);
    name_correct = false;   // As default name is not valid
    path_correct = false;   // As default path is not correct
 }

 void ProjectWindow::checkName()
 {
    QString name = projEdit->text();
    if (pManager->checkProjectName(name) && (name != ""))   // Check that project name is not NULL and unique
    {
        name_correct = TRUE;
        this->new_project.name = name;
    }
    else name_correct = FALSE;
    updateAddButtonState();
 }

 void ProjectWindow::updateAddButtonState()
 {
    // Add button is visible if path and project name are correct
    this->addButton->setEnabled(name_correct && path_correct);
 }




