#ifndef MYDIRMODEL_H
#define MYDIRMODEL_H

#include <QDirModel>

class MyDirModel : public QDirModel
{
public:
    MyDirModel();
    QModelIndexList getExpandedFolders() const;
};

#endif // MYDIRMODEL_H
