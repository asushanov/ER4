#include "manager.h"

Manager* Manager::_instance = 0;

Manager* Manager::Instance()
{
    if (_instance == 0) {
        _instance = new Manager;
    }
    return _instance;
}

void Manager::setWindow(MainWindow* wind) {
    window = wind;
}

Manager::Manager()
{
    this->tabManager.setManager(this);
    userName = "Aleksey_ER4";
}

QString Manager::getUserName()
{
    return userName;
}

MainWindow*  Manager::getMainWindow()
{
    return window;
}

void Manager::AddNewProject(Project nP)
{
    this->projects.push_back(nP);
    this->updateProjectTree(&nP);
    updateProjectList();
    this->getMainWindow()->chooseProject->setCurrentIndex(projects.size()-1);
}

bool Manager::checkProjectName(QString new_name)
{
    for (int i = 0; i < this->projects.size(); i++)
        if (new_name == projects.at(i).name)
            return false;
    return true;
}

void Manager::updateProjectList()
{
    this->getMainWindow()->chooseProject->clear();
    for (int i = 0; i<projects.size(); i++)
        this->getMainWindow()->chooseProject->addItem(projects.at(i).name);
}

void Manager::switchToProject(QString name)
{
for (int i = 0; i<projects.size(); i++)
    if (projects.at(i).name == name)
        this->updateProjectTree(&projects.at(i));
}

void Manager::refresh()
{
    this->refreshProjectTree();
}

void Manager::refreshProjectTree()
{
    switchToProject(this->getMainWindow()->chooseProject->currentText());
}

int Manager::getProjectsSize()
{
    return projects.size();
}

Project Manager::getProjectData(int index) const
{
    return this->projects.at(index);
}

void Manager::updateProjectTree(const Project *pr)
{
    Project pp;
    if (settings.init_done)
    {
        // Save expanded history of currect tree model
        for (int i = 0; i < projects.size(); i++)
        {
            if ((projects.at(i).name == this->getMainWindow()->fileTree->getCurProjName()) &&
                (this->getMainWindow()->fileTree->getCurProjName() != ""))
            {
                projects[i].persistent = this->getMainWindow()->fileTree->getExpandedList();
            }
        }
        // Update "Project tree"
        this->getMainWindow()->fileTree->updateFileList(pr);
        // Restore expanded folders for new item
        this->getMainWindow()->fileTree->setExpandedList(pr->persistent);

        for (int i = 0; i<pr->persistent.size(); i++)
        this->getMainWindow()->textEdit->insertPlainText(pr->persistent[i] + "\n");
    };
}

void Manager::openFile(QString file_full_name)
{
    this->getMainWindow()->textEdit->insertPlainText(file_full_name + "\n");

    if (!this->tabManager.tabExist(file_full_name))
    {
        Tab_info* newTab = new Tab_info;
        newTab->file_path = file_full_name;
        newTab->updateFields();
        this->tabManager.addTab(*newTab);
        delete newTab;
    }
    this->tabManager.switchToTab(file_full_name);


}
