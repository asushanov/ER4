#ifndef MYTABWIDGET_H
#define MYTABWIDGET_H

#include <QTabWidget>
#include "import.h"

class myTabWidget : public QTabWidget
{
    Q_OBJECT
public:
    explicit myTabWidget(QWidget *parent = 0);
    void setNewTabBar(QTabBar* tB);

signals:

public slots:

};

#endif // MYTABWIDGET_H
