#include "mytab.h"

MyTab::MyTab(QWidget *parent) :
    QWidget(parent)
{
    document = new QTextEdit;
}
