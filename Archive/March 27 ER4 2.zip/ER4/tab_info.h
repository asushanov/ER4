#ifndef TAB_INFO_H
#define TAB_INFO_H

#include "import.h"
#include "mytab.h"

class MyTab;

class Tab_info
{
public:
    QString file_path;
    MyTab* tab;

    Tab_info();
    void setActive(bool active);
    void updateFields();
    QString getName();

private:
    QString name;
    bool active;
    bool saved;
};

#endif // TAB_INFO_H
