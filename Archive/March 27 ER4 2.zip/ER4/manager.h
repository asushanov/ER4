#ifndef MANAGER_H
#define MANAGER_H

#include "import.h"
#include "mainwindow.h"
#include "mydirmodel.h"
#include "tab_manager.h"
#include "project.h"
#include "high_lite_mode.h"
#include "settings.h"
#include "tab_info.h"

class Tab_manager;
class Project;
class MainWindow;

class Manager
{
private:
    static Manager * _instance; // Singlenton pointer to 'this' manager
    QVector<Project> projects;  // All projects list
    Tab_manager tabManager; // manager for open tabs
//    QVector<High_lite_mode> highlights;
    MainWindow* window;     // Pointer to main window
    QString userName;       // Current user name


public:
    Settings settings;
    static Manager* Instance();     // Method for singlenton
    void setWindow(MainWindow* wind);   // Set main window pointer
    MainWindow* getMainWindow();        // Get main window pointer
    QString getUserName();              // Get current user name, for project settings
    void AddNewProject(Project nP);     // Add new project to model, also call 'updateProjectList()'
    bool checkProjectName(QString new_name);    // Check that there is now the same name in projects
    void updateProjectList();           // Refresh "view" in GUI
    void switchToProject(QString name); // Change current project by name, as key
    int getProjectsSize();              // Quantity of projects for 'this' user
    Project getProjectData(int index) const;    // Get project by index
    void updateProjectTree(const Project* pr);  // Save expanded history for previous project,
        // update tree view by name os new project, set expanded folders in new project
    void openFile(QString file_full_name);  // Calls by double click on file 'event'

protected:
    Manager();                          // Constructor

public slots:
    void refresh();     // Global refresh all data
    void refreshProjectTree();  // Refresh project view due to selected project

};

#endif // MANAGER_H
