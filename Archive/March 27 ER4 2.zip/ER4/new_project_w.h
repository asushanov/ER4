#ifndef NEW_PROJECT_W_H
#define NEW_PROJECT_W_H

#include "manager.h"
#include "project.h"
#include "import.h"

class Manager;
class Project;

class ProjectWindow : public QDialog
 {
     Q_OBJECT

 public:
    ProjectWindow(QWidget *parent = 0);
    QStringList extensions;
    void setManager(Manager* pM);
    void reset();

 private slots:
    void browse();
    void add();
    void close();
    void updateFileList();
    void checkName();

 private:
    Manager* pManager;
    QLineEdit *projEdit;
    QComboBox *pathComboBox;
    QLabel *projLabel;
    QLabel *pathLabel;
    QPushButton *browseButton;
    QPushButton *closeButton;
    QPushButton *addButton;
    QComboBox *extensionComboBox;
    QLabel *extensionLabel;
    QTreeView *fileView;
    QDir currentDir;
    QDirModel *model;
    Project new_project;

    // NotFunctional components
    QGridLayout *mainLayout;
    QHBoxLayout *buttonsLayout;

    void updateAddButtonState();
    void showFiles(const QStringList &files);
    QComboBox *createComboBox(const QString &text = QString());
    QPushButton *createButton(const QString &text, const char *member);

 };

#endif // NEW_PROJECT_W_H
