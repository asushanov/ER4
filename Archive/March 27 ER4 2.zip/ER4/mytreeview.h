#ifndef MYTREEVIEW_H
#define MYTREEVIEW_H

#include <QTreeView>

class Manager;

class MyTreeView : public QTreeView
{
public:
    MyTreeView();
    void setManager(Manager* pM);

private:
    Manager* pManager;

protected:
    void mouseDoubleClickEvent(QMouseEvent *event);
};

#endif // MYTREEVIEW_H
