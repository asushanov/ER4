#include "tab_info.h"

Tab_info::Tab_info()
{
    this->tab = new MyTab;
}

void Tab_info::setActive(bool active)
{
    this->active = active;
}

void Tab_info::updateFields()
{
    QStringList splittedName = this->file_path.split("/");
    this->name = splittedName[splittedName.size() - 1];
    this->active = false;
    this->saved = false;
}

QString Tab_info::getName()
{
    return name;
}
