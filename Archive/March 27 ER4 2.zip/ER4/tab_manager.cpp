#include "tab_manager.h"
#include "manager.h"

Tab_manager::Tab_manager()
{
}

void Tab_manager::setManager(Manager *pM)
{
    pManager = pM;
}

bool Tab_manager::tabExist(QString path) const
{
    for (int i = 0; i<this->tabs.size(); i++)
        if (this->tabs.at(i).file_path == path)
            return true;
    return false;
}

void Tab_manager::addTab(Tab_info tB)
{
    this->tabs.push_back(tB);
    this->pManager->getMainWindow()->tabMain->addTab(this->getTabInfo(tabs.size() - 1)->tab->document, tB.getName());
    if (pManager->settings.show_hints)
        this->pManager->getMainWindow()->tabBar->setTabToolTip(tabs.size()-1, tB.file_path);
}

void Tab_manager::switchToTab(QString path)
{
    // Change model state
    int tab_index = this->getIndexByName(path);
    this->setActive(tab_index);
    // Change GUI state : Go to necessary tab
    this->pManager->getMainWindow()->tabMain->setCurrentIndex(tab_index);


}

int Tab_manager::getIndexByName(QString path) const
{
    for (int i = 0; i < this->tabs.size(); i++)
        if (path == this->tabs.at(i).file_path)
            return i;
    return -1;
}

void Tab_manager::setActive(int index)
{
    for (int i = 0; i < this->tabs.size(); i++)
        this->tabs[i].setActive(i == index);
}

Tab_info* Tab_manager::getTabInfo(int pos)
{
    return &this->tabs[pos];
}

