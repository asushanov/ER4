#ifndef TYPES_H
#define TYPES_H

enum high_light_t {E_hl, Hdl_hl, None_hl};
enum file_folder_t {File_ff, Folder_ff};

#endif // TYPES_H
