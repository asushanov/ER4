#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    pManager = Manager::Instance();
    pManager->setWindow(this);

    ui->setupUi(this);
    InitWidgets_m();
    SetLocation_m();
    SetLimits_m();
    SetConfigs_m();
    ShowWidgets_m();
    readSettings();

    QObject::connect(ui->actionNew, SIGNAL(triggered()), this, SLOT(newProjectDialog()));
    QObject::connect(this->chooseProject, SIGNAL(currentIndexChanged(int)), this, SLOT(changeProject()));
    QObject::connect(ui->actionRefresh, SIGNAL(triggered()), this, SLOT(globalRefresh()));

}

MainWindow::~MainWindow()
{
    delete this->fileTree;
    delete ui;
}

void MainWindow::ShowWidgets_m()
{
    ui->mainToolBar->addWidget(findEdit);
    // Set Project dock location
    QGridLayout* projectLayout = new QGridLayout;
    projectLayout->addWidget(editProjects, 0, 0);
    projectLayout->addWidget(chooseProject, 0, 1);
    projectLayout->addWidget(fileTree->getTreeView(), 1, 0, 1, 2);
    projectLayout->setSpacing(2);
    projectLayout->setMargin(2);
    projectTreeW->setLayout(projectLayout);
    ui->dockTree->setWidget(projectTreeW);

    ui->dockOutput->setWidget(textEdit);
    High_lite_mode* highlighter = new High_lite_mode(this->textEdit->document());
}

void MainWindow::InitWidgets_m()
{
    findEdit = new QLineEdit;
    textLinesNumber = new QTextEdit;
    tabMain = new myTabWidget;
    chooseProject = new QComboBox;
    fileTree = new TreeProjectView();
    projectTreeW = new QWidget;
    editProjects = new QToolButton;
    tabBar = new QTabBar;

    textEdit = new QTextEdit;

}

void MainWindow::SetLocation_m()
{
    QSplitter *splitter = new QSplitter;
    splitter->addWidget(textLinesNumber);
    splitter->addWidget(tabMain);
    QHBoxLayout *leftLayout = new QHBoxLayout;
    leftLayout->setSpacing(1);
    leftLayout->setMargin(1);
    leftLayout->addWidget(splitter);
    ui->centralWidget->setLayout(leftLayout);
}

void MainWindow::SetConfigs_m()
{
    //fileTree->setColumnCount(2);
    editProjects->setText("...");
    tabMain->setNewTabBar(tabBar);
    //tabMain->setMovable(true);      // !!!!
    tabBar->setTabsClosable(true);
    tabBar->setDocumentMode(true);
    tabMain->setUsesScrollButtons(true);
    tabMain->setTabPosition(QTabWidget::South);
    tabMain->setTabShape(QTabWidget::Triangular);
}

void MainWindow::postInit_m()
{
    newProjectWindow->setManager(this->pManager);
    this->fileTree->setManager(this->pManager);
    pManager->updateProjectList();
    // Update Current Project
    QSettings projSettings("ProjectSettings", QSettings::NativeFormat);
    projSettings.beginGroup("ProjectsData_"+pManager->getUserName());
    this->chooseProject->setCurrentIndex(projSettings.value("LastOpenedProjIdx").toInt());
    projSettings.endGroup();

    // Refresh all restored components & data
    pManager->settings.init_done = true;
    pManager->refresh();
}

void MainWindow::SetLimits_m()
{
    textLinesNumber->setMaximumWidth(70);
    textLinesNumber->setMinimumWidth(30);
}

void MainWindow::closeEvent(QCloseEvent *event)
 {
    writeSettings();
    event->accept();
 }

void MainWindow::writeSettings()
{
    QSettings settings ("ER4");
    settings.beginGroup("GUISettings"+pManager->getUserName());
    settings.setValue("geometry", saveGeometry());
    settings.setValue("windowState", saveState());
    settings.endGroup();
    // Projects settings
    QSettings projSettings("ProjectSettings", QSettings::NativeFormat);
    projSettings.beginGroup("ProjectsData_"+pManager->getUserName());
    projSettings.setValue("PQuantity", pManager->getProjectsSize());
    Project projTemp;
    for (int i = 0; i<pManager->getProjectsSize(); i++)
    {
        projTemp = pManager->getProjectData(i);
        projSettings.setValue("Path"+i, projTemp.path);
        projSettings.setValue("Name"+i, projTemp.name);
        projSettings.setValue("Filter"+1, projTemp.filter);
    }
    projSettings.setValue("LastOpenedProjIdx", this->chooseProject->currentIndex());
    projSettings.endGroup();
}

void MainWindow::readSettings()
{
    QSettings settings ("ER4");
    settings.beginGroup("GUISettings"+pManager->getUserName());
    restoreGeometry(settings.value("geometry").toByteArray());
    restoreState(settings.value("windowState").toByteArray());
    settings.endGroup();
    // ProjectSettings
    QSettings projSettings("ProjectSettings", QSettings::NativeFormat);
    projSettings.beginGroup("ProjectsData_"+pManager->getUserName());
    int projectsQuantity = projSettings.value("PQuantity").toInt();
    Project projTemp;
    for (int i = 0; i<projectsQuantity; i++)
    {
        projTemp.path = projSettings.value("Path"+i).toString();
        projTemp.name = projSettings.value("Name"+i).toString();
        projTemp.filter = projSettings.value("Filter"+i).toStringList();
        pManager->AddNewProject(projTemp);
    }
    projSettings.endGroup();
    // NOTE : Additional last project settings will be read in "post_init" method
}

void MainWindow::newProjectDialog()
{
    newProjectWindow->setModal(true);
    newProjectWindow->show();
    newProjectWindow->reset();
}

void MainWindow::changeProject()
{
    pManager->refreshProjectTree();
}

void MainWindow::globalRefresh()
{
    pManager->refresh();
}
