#include "mydirmodel.h"

MyDirModel::MyDirModel()
{
}

QModelIndexList MyDirModel::getExpandedFolders() const
{
    return this->persistentIndexList();
}
