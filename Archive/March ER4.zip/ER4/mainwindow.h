#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "import.h"
#include <QMainWindow>
#include "new_project_w.h"

namespace Ui {
    class MainWindow;
}

class Manager;
class ProjectWindow;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QLineEdit* findEdit;
    QTextEdit* textLinesNumber;
    QTabWidget* tabMain;
    TreeProjectView* fileTree;
    QComboBox* chooseProject;
    QWidget *projectTreeW;
    Manager* pManager;
    ProjectWindow* newProjectWindow;
    QToolButton* editProjects;

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void writeSettings();
    void readSettings();
    void postInit_m();

    QTextEdit* textEdit;

public slots:
    void newProjectDialog();
    void changeProject();
    void globalRefresh();

private:
    Ui::MainWindow *ui;
    void ShowWidgets_m();
    void InitWidgets_m();
    void SetConfigs_m();
    void SetLimits_m();
    void SetLocation_m();

protected:
     void closeEvent(QCloseEvent *event);
};

#endif // MAINWINDOW_H
