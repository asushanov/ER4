#ifndef MANAGER_H
#define MANAGER_H

#include "import.h"
#include "mainwindow.h"
#include "mydirmodel.h"
#include "tab_manager.h"
#include "project.h"
#include "high_lite_mode.h"
#include "settings.h"

class Tab_manager;
class Project;
class MainWindow;

class Manager
{
private:
    static Manager * _instance;
    QVector<Project> projects;
    Tab_manager tabManager;
//    QVector<High_lite_mode> highlights;
    MainWindow* window;
    QString userName;


public:
    Settings settings;
    static Manager* Instance();
    void setWindow(MainWindow* wind);
    MainWindow* getMainWindow();
    QString getUserName();
    void AddNewProject(Project nP);
    bool checkProjectName(QString new_name);
    void updateProjectList();
    void switchToProject(QString name);
    int getProjectsSize();
    Project getProjectData(int index) const;
    void updateProjectTree(const Project* pr);
    void openFile(QString file_full_name);

protected:
    Manager();

public slots:
    void refresh();     // Global refresh all data
    void refreshProjectTree();  // Refresh project view due to selected project

};

#endif // MANAGER_H
