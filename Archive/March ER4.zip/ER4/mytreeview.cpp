#include "mytreeview.h"
#include "manager.h"

MyTreeView::MyTreeView()
{
}

void MyTreeView::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (pManager->getMainWindow()->fileTree->model->fileInfo(this->currentIndex()).isFile())
        // Open file or switch to it
        pManager->openFile(pManager->getMainWindow()->fileTree->model->fileInfo(this->currentIndex()).absoluteFilePath());
    // If folder - change expanded state
    else if (pManager->getMainWindow()->fileTree->model->fileInfo(this->currentIndex()).isDir())
    {
        this->setExpanded(this->currentIndex(), !this->isExpanded(this->currentIndex()));
        // Update column width
        pManager->getMainWindow()->fileTree->updateColumnWidth();
    }
}

void MyTreeView::setManager(Manager *pM)
{
    pManager = pM;
}
