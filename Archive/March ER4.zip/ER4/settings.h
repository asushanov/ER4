#ifndef SETTINGS_H
#define SETTINGS_H

class Settings
{
public:
    Settings();
    bool save_expanded_history;     // Save - restore expanded history for NOT last project
    bool save_only_last_proj_exp_history;   // Save last project expanded history
    bool expand_on_proj_change;     // Save expanded history during working, GLOBAL
    bool init_done;                 // Initialising.Not refresh each item on init stage
};

#endif // SETTINGS_H
