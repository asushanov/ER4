#include "treeprojectview.h"
#include "manager.h"

TreeProjectView::TreeProjectView()
{
    model = new MyDirModel;
}

void TreeProjectView::updateFileList(const Project* Pr)
{
    model->setFilter(QDir::AllDirs | QDir::Files | QDir::NoSymLinks | QDir::NoDotAndDotDot);
    model->setNameFilters(QStringList(Pr->filter));
    this->treeView.setModel(model);
    this->treeView.setRootIndex(model->index(Pr->path));
    this->currect_project_name = Pr->name;
    // TODO
    hide_file_name = false;
    hide_file_size = true;
    hide_file_kind = true;
    hide_file_date = true;

    this->treeView.setColumnHidden(0, hide_file_name);
    this->treeView.setColumnHidden(1, hide_file_size);
    this->treeView.setColumnHidden(2, hide_file_kind);
    this->treeView.setColumnHidden(3, hide_file_date);
}

MyTreeView* TreeProjectView::getTreeView()
{
    return &this->treeView;
}

QStringList TreeProjectView::getExpandedList()
{
    QStringList result;
    foreach (QModelIndex index, model->getExpandedFolders())
    {
        if (this->treeView.isExpanded(index))
        {
            //result.push_back(index.data(Qt::DisplayRole).toString());
            //result.push_back(index.data(Qt::UserRole).toString());
            //result.push_back(model->fileInfo(treeView.currentIndex()).path());
            //this->treeView.setExpanded(index, false);

        }
    }

    return result;
}

void TreeProjectView::setExpandedList(const QStringList expands)
{
    foreach(QString item, expands)
    {
        QModelIndexList Items = model->match(model->index(0, 0), Qt::DisplayRole, QVariant::fromValue(item));
        if (!Items.isEmpty())
        {
            this->treeView.setExpanded(Items.first(), true);
        }
    }
}

QString TreeProjectView::getCurProjName()
{
    return this->currect_project_name;
}

void TreeProjectView::setManager(Manager *pM)
{
    pManager = pM;
    this->treeView.setManager(pM);
}

void TreeProjectView::updateColumnWidth()
{
    this->treeView.resizeColumnToContents(0);
}
