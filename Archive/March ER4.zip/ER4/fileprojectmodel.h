#ifndef FILEPROJECTMODEL_H
#define FILEPROJECTMODEL_H

#include <QDirModel>

class FileProjectModel : public QDirModel
        //QFileSystemModel
{


};

#endif // FILEPROJECTMODEL_H
