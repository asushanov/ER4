#include "new_project_w.h"

ProjectWindow::ProjectWindow(QWidget *parent) : QDialog(parent)
 {
    projLabel = new QLabel(tr("Project name:"));
    pathLabel = new QLabel(tr("Path:"));
    projEdit = new QLineEdit();
    pathComboBox = createComboBox(tr("PATH"));
    extensionLabel = new QLabel(tr("File extensions"));
    extensionComboBox = createComboBox(tr("EXTENSIONS"));
    browseButton = createButton(tr("&Browse"), SLOT(browse()));
    addButton = createButton(tr("& Add "), SLOT(add()));
    closeButton = createButton(tr("&Close"), SLOT(close()));
    //fileView = new QTableWidget();
    //fileView->setColumnCount(2);
    fileView = new QTreeView();
    model = new FileProjectModel;

    //fileView->setSelectionBehavior(QAbstractItemView::SelectRows);
    //QStringList labels;
    //labels << tr("File Name") << tr("Size");
    //fileView->setHorizontalHeaderLabels(labels);
    //fileView->horizontalHeader()->setResizeMode(0, QHeaderView::Stretch);
    //fileView->verticalHeader()->hide();
    //fileView->setShowGrid(false);

    QGridLayout *mainLayout = new QGridLayout;
    QHBoxLayout *buttonsLayout = new QHBoxLayout;
    mainLayout->addWidget(projLabel, 0, 0);
    mainLayout->addWidget(projEdit, 0, 1, 1, 2);
    mainLayout->addWidget(pathLabel, 1, 0);
    mainLayout->addWidget(pathComboBox, 1, 1, 1, 2);
    mainLayout->addWidget(extensionLabel, 2, 0);
    mainLayout->addWidget(extensionComboBox, 2, 1);
    mainLayout->addWidget(browseButton, 2, 2);
    mainLayout->addWidget(fileView, 3, 0, 1, 3);
    buttonsLayout->addStretch();
    buttonsLayout->addWidget(closeButton, 0);
    buttonsLayout->addWidget(addButton, 1, Qt::AlignRight);
    mainLayout->addLayout(buttonsLayout, 4, 0, 1, 3);

    setLayout(mainLayout);

    setWindowTitle(tr("Add new project"));
    resize(600, 370);
 }

QComboBox *ProjectWindow::createComboBox(const QString &text)
{
    QComboBox *comboBox = new QComboBox;
    comboBox->setEditable(true);
    if (text == "EXTENSIONS") {
        comboBox->addItem("*.e *.hdl");
        comboBox->addItem("*.hdl");
        comboBox->addItem("*.e");
        comboBox->addItem("*.*");
    } else if (text == "PATH") {

    };
    comboBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    return comboBox;
}

QPushButton *ProjectWindow::createButton(const QString &text, const char *member)
{
    QPushButton *button = new QPushButton(text);
    connect(button, SIGNAL(clicked()), this, member);
    return button;
}

void ProjectWindow::browse()
{
    QString directory = QFileDialog::getExistingDirectory(this,
                               tr("Find Files"), "~/");
    if (!directory.isEmpty()) {
        if (pathComboBox->findText(directory) == -1)
            pathComboBox->addItem(directory);
        pathComboBox->setCurrentIndex(pathComboBox->findText(directory));
    }
}

void ProjectWindow::add()
{
    updateFileList();
}

void ProjectWindow::close()
{
    pathComboBox->clearEditText();
    projEdit->clear();
    //fileView->clear();
    this->hide();
}

 void ProjectWindow::setManager(Manager *pM)
 {
     pManager = pM;
 }

 static void updateComboBox(QComboBox *comboBox)
 {
     if (comboBox->findText(comboBox->currentText()) == -1)
         comboBox->addItem(comboBox->currentText());
 }

 void ProjectWindow::updateFileList()
 {

    QString extensions = extensionComboBox->currentText();
    QString path = pathComboBox->currentText();
    updateComboBox(extensionComboBox);
    updateComboBox(pathComboBox);

    currentDir = QDir(path);
    QStringList files;
    if (extensions.isEmpty())
         extensions = "*.*";
    files = currentDir.entryList(QStringList(extensions), QDir::Files | QDir::NoSymLinks | QDir::AllDirs | QDir::NoDotAndDotDot);
//    for (int i = 0; i < files.size(); ++i) {
//        QTableWidgetItem *fileNameItem = new QTableWidgetItem(files[i]);
//        QFile file(currentDir.absoluteFilePath(files[i]));
//        qint64 size = QFileInfo(file).size();
//        fileNameItem->setFlags(fileNameItem->flags() ^ Qt::ItemIsEditable);
//        QTableWidgetItem *sizeItem = new QTableWidgetItem(tr("%1 KB") .arg(int((size + 1023) / 1024)));
//        sizeItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
//        sizeItem->setFlags(sizeItem->flags() ^ Qt::ItemIsEditable);

//        int row = fileView->rowCount();
//        fileView->insertRow(row);
//        fileView->setItem(row, 0, fileNameItem);
//        fileView->setItem(row, 1, sizeItem);

//   }


    model->setNameFilters(QStringList(extensions));
    model->setFilter(QDir::AllDirs | QDir::Files | QDir::NoSymLinks | QDir::NoDotAndDotDot);
    fileView->setModel(model);
    fileView->setRootIndex(model->index(path));
    model->setRootPath(path);
    fileView->setColumnWidth(0, 210);
    update_position();
 }

 void ProjectWindow::update_position()
 {
     pManager->getMainWindow()->resize(300, 400);
 }
