#ifndef ADD_PROJECT_WINDOW_H
#define ADD_PROJECT_WINDOW_H

#include "import.h"

class AddProjectWindow : public QDialog
 {
     Q_OBJECT

 public:
     AddProjectWindow(QWidget *parent = 0);

 private slots:
     void browse();
     void find();
     void openFileOfItem(int row, int column);

 private:
     QStringList findFiles(const QStringList &files, const QString &text);
     void showFiles(const QStringList &files);
     QPushButton *createButton(const QString &text, const char *member);
     QComboBox *createComboBox(const QString &text = QString());
     void createFilesTable();

     QComboBox *fileComboBox;
     QComboBox *textComboBox;
     QComboBox *directoryComboBox;
     QLabel *fileLabel;
     QLabel *textLabel;
     QLabel *directoryLabel;
     QLabel *filesFoundLabel;
     QPushButton *browseButton;
     QPushButton *findButton;
     QTableWidget *filesTable;

     QDir currentDir;
 };

#endif // ADD_PROJECT_WINDOW_H
