#ifndef HIGH_LITE_MODE_H
#define HIGH_LITE_MODE_H

class High_lite_mode
{
public:
    High_lite_mode();
};

#endif // HIGH_LITE_MODE_H
