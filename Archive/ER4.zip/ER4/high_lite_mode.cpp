#include "high_lite_mode.h"

High_lite_mode::High_lite_mode()
{
}
