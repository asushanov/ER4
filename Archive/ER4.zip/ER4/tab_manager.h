#ifndef TAB_MANAGER_H
#define TAB_MANAGER_H

#include "import.h"

class Tab_manager
{
public:
    Tab_manager();
};

#endif // TAB_MANAGER_H
