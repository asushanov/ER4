#ifndef TREEPROJECTVIEW_H
#define TREEPROJECTVIEW_H

#include <QTreeWidget>

class TreeProjectView : public QTreeWidget
{

};

#endif // TREEPROJECTVIEW_H
