#ifndef MANAGER_H
#define MANAGER_H

#include "import.h"
#include "tab_manager.h"
#include "project.h"
#include "high_lite_mode.h"
#include "mainwindow.h"

class Tab_manager;
class Project;

class Manager
{
private:
    static Manager * _instance;

    QVector<Project> projects;
    Tab_manager tabManager;
    QVector<High_lite_mode> highlights;
    QMainWindow* window;
    QString userName;

public:
    static Manager* Instance();
    void setWindow(QMainWindow* wind);
    QMainWindow* getMainWindow();
    QString getUserName();
protected:
    Manager();
};

#endif // MANAGER_H
