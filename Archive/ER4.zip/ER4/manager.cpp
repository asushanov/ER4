#include "manager.h"

Manager* Manager::_instance = 0;

Manager* Manager::Instance()
{
    if (_instance == 0) {
        _instance = new Manager;
    }
    return _instance;
}

void Manager::setWindow(QMainWindow* wind) {
    window = wind;
}

Manager::Manager()
{
    userName = "Aleksey_ER4";
}

QString Manager::getUserName()
{
    return userName;
}

QMainWindow*  Manager::getMainWindow()
{
    return window;
}
