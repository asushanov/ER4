#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "manager.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    pManager = Manager::Instance();
    pManager->setWindow(this);

    ui->setupUi(this);
    InitWidgets_m();
    SetLocation_m();
    SetLimits_m();
    SetConfigs_m();
    ShowWidgets_m();
    readSettings();

    QObject::connect(ui->actionAdd, SIGNAL(triggered()), this, SLOT(addProjectDialog()));
    QObject::connect(ui->actionNew, SIGNAL(triggered()), this, SLOT(newProjectDialog()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ShowWidgets_m()
{
    ui->mainToolBar->addWidget(findEdit);
    ui->dockTree->setWidget(fileTree);
}

void MainWindow::InitWidgets_m()
{
    findEdit = new QLineEdit;
    textLinesNumber = new QTextEdit;
    tabMain = new QTabWidget;
    fileTree = new TreeProjectView();

}

void MainWindow::SetLocation_m()
{
    QSplitter *splitter = new QSplitter;
    splitter->addWidget(textLinesNumber);
    splitter->addWidget(tabMain);
    QHBoxLayout *leftLayout = new QHBoxLayout;
    leftLayout->setSpacing(1);
    leftLayout->setMargin(1);
    leftLayout->addWidget(splitter);
    ui->centralWidget->setLayout(leftLayout);
}

void MainWindow::SetConfigs_m()
{
    //fileTree->setColumnCount(2);

}

void MainWindow::postInit_m()
{
    newProjectWindow->setManager(this->pManager);
}

void MainWindow::SetLimits_m()
{
    textLinesNumber->setMaximumWidth(70);
    textLinesNumber->setMinimumWidth(30);
}

void MainWindow::closeEvent(QCloseEvent *event)
 {
    writeSettings();
    event->accept();
 }

void MainWindow::writeSettings()
{
    QSettings settings ("ER4");
    settings.beginGroup("GUISettings"+pManager->getUserName());
    settings.setValue("geometry", saveGeometry());
    settings.setValue("windowState", saveState());
    settings.endGroup();
}

void MainWindow::readSettings()
{
    QSettings settings ("ER4");
    settings.beginGroup("GUISettings"+pManager->getUserName());
    restoreGeometry(settings.value("geometry").toByteArray());
    restoreState(settings.value("windowState").toByteArray());
    settings.endGroup();

}

void MainWindow::addProjectDialog()
{
    //addProjectWindow->setModal(true);
    addProjectWindow->show();
}

void MainWindow::newProjectDialog()
{
    newProjectWindow->setModal(true);
    newProjectWindow->show();
}

