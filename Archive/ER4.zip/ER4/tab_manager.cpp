#include "tab_manager.h"

Tab_manager::Tab_manager()
{
}
