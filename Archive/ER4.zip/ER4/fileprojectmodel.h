#ifndef FILEPROJECTMODEL_H
#define FILEPROJECTMODEL_H

#include <QFileSystemModel>

class FileProjectModel : public QFileSystemModel
{


};

#endif // FILEPROJECTMODEL_H
