#ifndef NEW_PROJECT_W_H
#define NEW_PROJECT_W_H

#include "manager.h"
#include "import.h"

class Manager;

class ProjectWindow : public QDialog
 {
     Q_OBJECT

 public:
    ProjectWindow(QWidget *parent = 0);
    void setManager(Manager* pM);

 private slots:
    void browse();
    void add();
    void close();
    void updateFileList();

 private:
    Manager* pManager;
    QLineEdit *projEdit;
    QComboBox *pathComboBox;
    QLabel *projLabel;
    QLabel *pathLabel;
    QPushButton *browseButton;
    QPushButton *closeButton;
    QPushButton *addButton;
    QComboBox *extensionComboBox;
    QLabel *extensionLabel;
    //QTableWidget *fileView;
    QTreeView *fileView;
    QDir currentDir;
    FileProjectModel *model;
    void showFiles(const QStringList &files);
    QComboBox *createComboBox(const QString &text = QString());
    QPushButton *createButton(const QString &text, const char *member);
    void update_position();
 };



#endif // NEW_PROJECT_W_H
