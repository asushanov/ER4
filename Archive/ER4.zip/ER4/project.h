#ifndef PROJECT_H
#define PROJECT_H

#include "import.h"

class Project
{
public:
    Project();
    void UpdateFiles();
    QDir path;
    QString name;       // Project name
    QString filter;     // Extensions filter
};

#endif // PROJECT_H
