#ifndef IMPORT_H
#define IMPORT_H

#include <QLineEdit>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QTabWidget>
#include <QSplitter>
#include <QSplashScreen>
#include <QImage>
#include <QPixmap>
#include <QDir>
#include <QSettings>
#include <QCloseEvent>
#include <QSize>
#include <QDockWidget>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QDialog>
#include <QLabel>
#include <QComboBox>
#include <QPushButton>
#include <QTableWidget>
#include <QDesktopServices>
#include <QUrl>
#include <QProgressDialog>
#include <QFileDialog>
#include <QTextStream>
#include <QHeaderView>
#include <QSyntaxHighlighter>
#include <QDirModel>
#include <QModelIndex>
#include <QFile>
#include <QFileSystemModel>
#include <QStringList>

#include "fileprojectmodel.h"
#include "treeprojectview.h"

#endif // IMPORT_H
