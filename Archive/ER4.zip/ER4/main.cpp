#include "import.h"
#include "manager.h"
#include <QtGui/QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    Manager * pManager;
    pManager = Manager::Instance();
    QApplication a(argc, argv);

    QPixmap pixmap(QDir::currentPath()+"/1.png");

    QSplashScreen *splash = new QSplashScreen(pixmap);
    splash->show();
    //splash->showMessage("Loaded modules");
    //processEvents();
    delete splash;

    MainWindow w;
    AddProjectWindow addProj;
    ProjectWindow newProj;
    w.newProjectWindow = &newProj;
    w.addProjectWindow = &addProj;
    a.setActiveWindow(&w);
    w.show();

    w.findEdit->setText(QDir::currentPath());
    w.postInit_m();
    return a.exec();
}
